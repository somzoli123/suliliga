<?php

namespace App\Filament\Resources\Teams\Tables;

use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class TeamsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')
                    ->label('Csapat')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('class_name')
                    ->label('Osztály')
                    ->sortable(),

                TextColumn::make('captain_name')
                    ->label('Kapitány')
                    ->searchable(),

                TextColumn::make('players.name')
                    ->label('Játékosok')
                    ->listWithLineBreaks()
                    ->bulleted(),

                TextColumn::make('players.jersey_number')
                    ->label('Mezszámok')
                    ->listWithLineBreaks()
                    ->bulleted(),

                TextColumn::make('status')
                    ->label('Állapot')
                    ->badge()
                    ->formatStateUsing(fn (string $state): string => match ($state) {
                        'pending' => 'Jóváhagyásra vár',
                        'approved' => 'Jóváhagyva',
                        'rejected' => 'Elutasítva',
                        default => $state,
                    }),
            ])
            ->recordActions([
                EditAction::make()->label('Szerkesztés'),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make()->label('Kijelöltek törlése'),
                ]),
            ]);
    }
}
